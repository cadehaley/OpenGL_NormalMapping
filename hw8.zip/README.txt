Cade Haley - CSCI 4239  -  Homework 8

This program demonstrates the huge boost in visual realism that the use of normal maps can provide as a cool texture trick. You can think of it as using a texture to store per-pixel imperfections and bumps for greater lighting detail. It is all shader effects and uses no other geometry than the 8 verts of the cube.

Launch the executable ex06 and use the on-screen controls to alter the view options.
Also, click and drag on the view window to rotate and zoom with the mouse wheel

Note: Fixed pipeline was forgotten about

Completion time: 6.5 hours
