Cade Haley - CSCI 4239  -  Homework 4

Launch the executable ex06 and use the on-screen controls to alter the view options.
Make sure to select 'Programmable Pipeline' to see OpenGL 4 shader lighting
Also, click and drag on the view window to rotate and zoom with the mouse wheel

Completion time: 4 hours
